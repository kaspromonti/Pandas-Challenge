## Cleaning Kickstarter

### Instructions

* The instructions for this activity are contained within the Jupyter Notebook.

Data Source: [Kickstarter Datasets](https://webrobots.io/kickstarter-datasets/)
