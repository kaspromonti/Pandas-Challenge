# Data-Frame Shop

## Instructions

* Create a DataFrame for a frame shop that contains three columns - "Frame", "Price", and "Sales" - and has five rows of data stored within it.

* Using an alternate method from that used before, create a DataFrame for an art gallery that contains three columns - "Painting", "Price", and "Popularity" - and has four rows of data stored within it.

## Bonus

* Once both of the DataFrames have been created, discuss with those around you which method you prefer to use and why.
